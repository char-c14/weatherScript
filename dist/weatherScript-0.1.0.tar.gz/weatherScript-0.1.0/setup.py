# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['weatherscript']

package_data = \
{'': ['*']}

install_requires = \
['pip==20.2.3', 'requests==2.24.0', 'urllib3==1.25.11']

setup_kwargs = {
    'name': 'weatherscript',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'char-c14',
    'author_email': 'saha.rajarshi17@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.0',
}


setup(**setup_kwargs)
