from weatherscript.weatherScript import weatherInstance

__version__ = '0.1.0'